// 키비주얼 영상: 접속 시 자동 재생, 무한 반복. 화면 밖·다른 탭에서는 멈추고, 동작 줄이기 설정이면 정지 이미지만 표시
function initKvMotion() {
	const section = document.querySelector('.sec_kv');
	if (!section) return;
	const video = section.querySelector('.kv_video');
	if (!video) return;

	const mobile = window.matchMedia('(max-width: 768px)');
	const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
	let inView = true;

	function source() {
		return (mobile.matches && video.dataset.srcMo) ? video.dataset.srcMo : video.dataset.srcPc;
	}

	function sync() {
		if (reduced.matches || !inView || document.hidden) {
			video.pause();
			return;
		}
		const src = source();
		if (video.getAttribute('src') !== src) {
			video.src = src;
			video.load();
		}
		video.play().catch(() => {});
	}

	document.addEventListener('visibilitychange', sync);
	mobile.addEventListener('change', sync);
	reduced.addEventListener('change', sync);
	if ('IntersectionObserver' in window) {
		new IntersectionObserver((entries) => {
			inView = entries[0].isIntersecting;
			sync();
		}, { threshold: .08 }).observe(section);
	}
	sync();
}

// 헤더 메뉴: 보고 있는 섹션 표시, 모바일 메뉴는 항목을 누르면 닫힘
function initAnchorNav() {
	const header = document.querySelector('.header');
	if (!header) return;
	const links = header.querySelectorAll('.header_nav a, .header_mobile_nav nav a');
	const groups = { sec_why: 'sec_about', sec_makers: 'sec_about' };
	const sections = [...document.querySelectorAll('.wrap section[id]')];

	function update() {
		const line = header.offsetHeight + 120;
		let current = '';
		sections.forEach((section) => {
			if (section.getBoundingClientRect().top <= line) current = section.id;
		});
		const target = '#' + (groups[current] || current);
		links.forEach((link) => link.classList.toggle('active', link.getAttribute('href') === target));
	}

	let ticking = false;
	window.addEventListener('scroll', () => {
		if (ticking) return;
		ticking = true;
		requestAnimationFrame(() => {
			update();
			ticking = false;
		});
	}, { passive: true });
	update();

	const toggle = header.querySelector('.header_toggle');
	header.querySelectorAll('.header_mobile_nav a').forEach((link) => {
		link.addEventListener('click', () => {
			header.classList.remove('is-active');
			if (toggle) toggle.setAttribute('aria-expanded', 'false');
		});
	});
}

// 아코디언 (연차별·FAQ 공통): 목록에 data-mode="single"(하나만 열림) / "multiple"(여러 개 열림)
// 항목 안의 첫 번째 button[aria-controls]로 열고 닫음, 열리면 항목에 is-open
function initAccordion(listSelector, itemSelector) {
	document.querySelectorAll(listSelector).forEach((list) => {
		const single = list.dataset.mode === 'single';
		const items = [...list.querySelectorAll(itemSelector)];

		function setOpen(item, open) {
			const button = item.querySelector('button[aria-controls]');
			const panel = button && document.getElementById(button.getAttribute('aria-controls'));
			if (!panel) return;
			item.classList.toggle('is-open', open);
			button.setAttribute('aria-expanded', String(open));
			panel.hidden = !open;
		}

		items.forEach((item) => {
			setOpen(item, false);
			const button = item.querySelector('button[aria-controls]');
			if (!button) return;
			button.addEventListener('click', () => {
				const open = !item.classList.contains('is-open');
				if (open && single) items.forEach((other) => { if (other !== item) setOpen(other, false); });
				setOpen(item, open);
			});
		});
	});
}

document.addEventListener('DOMContentLoaded', () => {
	initKvMotion();
	initAnchorNav();
	initAccordion('.sec_journey .year_list', '.year_item');
	initAccordion('.sec_faq .faq_list', '.faq_item');
});
